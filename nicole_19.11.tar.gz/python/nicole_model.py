import numpy as np

class model:
    nx=1
    ny=1
    nz=1
    version='1804'
    
    def __repr__(self):
        return 'NICOLE model atmosphere, version {}'.format(self.version)

    def __str__(self):
        return 'NICOLE model atmosphere, version {}'.format(self.version)

    def __len__(self):
        return self.nx*self.ny

    def __getitem__(self,position):
        if type(position) == int: # runs faster on iy
            ix=int(position/self.ny)
            iy=position % self.ny
        else:
            ix=position[0]
            iy=position[1]
        n=self.copy(ix,iy)
        return n
    
    def __init__(self, nx=1, ny=1, nz=1):
        self.nx=nx
        self.ny=ny
        self.nz=nz

        self.depthvars='z tau t gas_p rho el_p v_los v_mic b_los_z b_los_x b_los_y b_x b_y b_z v_x v_y v_z mH nHminus nHplus nH2 nH2plus'
        self.vars='v_mac stray_frac ffactor keep_el_p keep_gas_p keep_rho keep_nH keep_nHminus keep_nHplus keep_nH2 keep_nH2plus chrom_x chrom_y'

        self.nvars=len(self.vars.split())
        for var in self.vars.split():
            code='self.'+var+'=np.zeros((nx,ny))'
            exec(code)
        self.ndepthvars=len(self.depthvars.split())
        for var in self.depthvars.split():
            code='self.'+var+'=np.zeros((nx,ny,nz))'
            exec(code)
        self.abundance=np.zeros((nx,ny,92))
        for ix in range(nx):
            for iy in range(ny):
                self.abundance[ix,iy,:]=[ 12.00,10.93,1.10,1.40,2.55,8.52,7.92,8.83,4.56,8.08,6.33,7.58,\
                6.47,7.55,5.45,7.33,5.5,6.40,5.12,6.36,3.17,5.02,4.00,5.67,\
                5.39,7.50,4.92,6.25,4.21,4.60,2.88,3.41,-10,-10,-10,-10,\
                2.60,2.97,2.24,2.60,1.42,\
                1.92,-10,1.84,1.12,1.69,0.94,1.77,1.66,2.0,1.0,-10,-10,-10,-10,\
                2.13,1.17,1.58,0.71,1.50,-10,1.01,0.51,1.12,-0.1,1.14,0.26,\
                0.93,0.00,1.08,0.06,0.88,-10,1.11,-10,1.45,1.35,1.8,1.01,-10,\
                     0.9,1.95,-10,-10,-10,-10,-10,-10,-10,-10,-10,-10]

    def check_types(self): # Utilities
        import struct

    # Check size of default types. Need 32-bit integers, 64-bit integers and floats
    # 32-bit integers
        if struct.calcsize('<i') == 4:
            int4f='i'
        elif struct.calcsize('<l') == 4:
            int4f='l'
        elif struct.calcsize('<q') == 4:
            int4f='q'
        else:
            print ('This architecture has a non-standard integer size')
            print ('which is not supported in this version. Please, contact the')
            print ('author to get support for this platform.')
            sys.exit(1)
    # 64-bit integers
        if struct.calcsize('<i') == 8:
            intf='i'
        elif struct.calcsize('<l') == 8:
            intf='l'
        elif struct.calcsize('<q') == 8:
            intf='q'
        else:
            print ('This architecture has a non-standard integer size')
            print ('which is not supported in this version. Please, contact the')
            print ('author to get support for this platform.')
            sys.exit(1)
    # 64-bit floats
        if struct.calcsize('<f') == 8:
            flf='f'
        elif struct.calcsize('<d') == 8:
            flf='d'
        else:
            print ('This architecture has a non-standard float size')
            print ('which is not supported in this version. Please, contact the')
            print ('author to get support for this platform.')
            sys.exit(1)
        return [int4f,intf,flf]
                
    def read(self,filename,error=False): # Read model from file
        import sys, os, struct
        
        [int4f,intf,flf]=self.check_types()
        try:
            f=open(filename,'rb')
        except:
            print ('Could not find model file:',filename)
            sys.exit(1)
        header=f.read(16+4+4+8)
        [string,nx,ny,nz]=struct.unpack('<16s'+int4f+int4f+intf,header)
        f.close()
        if string != b'nicole1804m     ':
            print('Incorrect version file. Verision string:',string)
            sys.exit(1)
        filesize=os.path.getsize(filename)
        if filesize != (22*nz+13+92)*(nx*ny+1)*8:
            print ('Incorrect size of model file:',filename)
            print ('The file is probably corrupted. Proceeding anyway...')
            error=True
        self.__init__(nx,ny,nz)
        
        sizerec=self.ndepthvars*nz+self.nvars+92
        f=open(filename,'rb')
        data=struct.unpack('<'+str(sizerec)+flf,f.read(sizerec*8))
        for ix in range(nx):
            for iy in range(ny):
                data=struct.unpack('<'+str(sizerec)+flf,f.read(sizerec*8))
                irec=0
                for var in self.depthvars.split():
                    code='self.'+var+'[ix,iy,:]=data[irec:irec+nz]'
                    exec(code)
                    irec=irec+nz
                for var in self.vars.split():
                    code='self.'+var+'[ix,iy]=data[irec]'
                    exec(code)
                    irec=irec+1
                self.abundance[ix,iy,:]=data[irec:irec+92]
                
                
    def write(self,filename): # Write model to file
        import sys, os, struct
        
        [int4f,intf,flf]=self.check_types()
        try:
            f=open(filename,'wb')
        except:
            print('Error! Unable to open file for writing')
            sys.exit(1)
        
        sizerec=self.ndepthvars*self.nz+self.nvars+92
        f.write(struct.pack('<16s'+int4f+int4f+intf,b'nicole1804m     ',self.nx,self.ny,self.nz)) # First record
        for i in range(int(sizerec-16/8-1-1)): f.write(struct.pack('<'+flf,0.)) # Fill rest of the record
        for ix in range(self.nx):
            for iy in range(self.ny):
                irec=0
                data=np.zeros((sizerec))
                for var in self.depthvars.split():
                    code='data[irec:irec+self.nz]=self.'+var+'[ix,iy,:]'
                    exec(code)
                    irec=irec+self.nz
                for var in self.vars.split():
                    code='data[irec]=self.'+var+'[ix,iy]'
                    exec(code)
                    irec=irec+1
                data[irec:irec+92]=self.abundance[ix,iy,:]
        
                f.write(struct.pack('<'+str(sizerec)+flf,*data))
        
        
    def copy(self,indx=None,indy=None): # Returns a new model with
                                        # columns indx and indy from
                                        # this one
        if indx == None:
            indx=range(self.nx)
        if indy == None:
            indy=range(self.ny)
        if type(indx) == int:
            indx=[indx]
        if type(indy) == int:
            indy=[indy]
            
        nx2=len(indx)
        ny2=len(indy)
        n=model(nx2,ny2,self.nz)
        for ix2 in range(nx2):
            for iy2 in range(ny2):
                ix=indx[ix2]
                iy=indy[iy2]
                for var in self.vars.split():
                    code='n.'+var+'['+str(ix2)+','+str(iy2)+']=self.'+var+\
                                '['+str(ix)+','+str(iy)+']'
                    exec(code)
                for var in self.depthvars.split():
                    code='n.'+var+'['+str(ix2)+','+str(iy2)+',:]=self.'+var+\
                                '['+str(ix)+','+str(iy)+',:]'
                    exec(code)

        return n
    
    def insert(self, n, ix, iy): # Insert model n at location ix, iy of self
        if ix > self.nx or iy > self.ny:
            print('Error. index out of range. (ix, iy)=({},{})'.format(ix,iy))
            print('(nx,ny)=({},{})'.format(self.nx,self.ny))
            sys.exit(1)
        for var in self.vars.split():
            code='self.'+var+'['+str(ix)+','+str(iy)+']=n.'+var+\
                                                         '['+str(0)+','+str(0)+']'
            exec(code)
        for var in self.depthvars.split():
            code='self.'+var+'['+str(ix)+','+str(iy)+',:]=n.'+var+\
                                        '['+str(0)+','+str(0)+',:]'
            exec(code)

           
    def increasing_tau(self): # Make sure model has tau increasing
        for ix in range(self.nx):
            for iy in range(self.ny):
                if self.tau[ix,iy,1]-self.tau[ix,iy,0] < 0:
                    for var in self.depthvars.split():
                        code='self.'+var+'['+str(ix)+','+str(iy)+',:]=np.flip(self.'+var+\
                            '['+str(0)+','+str(0)+',:],0)'
                        exec(code)

           
    def decreasing_tau(self): # Make sure model has tau decreasing
        for ix in range(self.nx):
            for iy in range(self.ny):
                if self.tau[ix,iy,1]-self.tau[ix,iy,0] > 0:
                    for var in self.depthvars.split():
                        code='self.'+var+'['+str(ix)+','+str(iy)+',:]=np.flip(self.'+var+\
                            '['+str(0)+','+str(0)+',:],0)'
                        exec(code)

    def get_var(self,label): # Get array with variable in string label
                             # e.g., T=model.get_var('T') to obtain temperature
                             # equivalent to T=model.t
                             # label match is case-independent
        label2=label.lower()
        if not label2 in self.vars:
            print('Error. Variable {} not found in model')
            sys.exit(1)
        code='self.out=self.'+label2
        exec(code)
        return(self.out)

    def set_var(self,label,array): # Set variable in string label
                             # e.g., model.get_var('T')=T to obtain temperature
                             # equivalent to model.t=T
                             # label match is case-independent
        label2=label.lower()
        if not label2 in self.vars:
            print('Error. Variable {} not found in model')
            sys.exit(1)
        code='self.'+label2+'=array'
        exec(code)
        return
    
        
        
