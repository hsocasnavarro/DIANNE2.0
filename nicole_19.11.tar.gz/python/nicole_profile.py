import numpy as np

class stokes:
    nx=1
    ny=1
    nlam=1
    version='2.3'
    
    def __repr__(self):
        return 'NICOLE stokes profiles, version {}'.format(self.version)

    def __str__(self):
        return 'NICOLE stokes profiles, version {}'.format(self.version)

    def __len__(self):
        return self.nx*self.ny

    def __getitem__(self,position): # runs faster on iy
        if type(position) == int: # runs faster on iy
            ix=int(position/self.ny)
            iy=position % self.ny
        else:
            ix=position[0]
            iy=position[1]
        stk2=self.copy(ix,iy)
        return stk2
    
    def __init__(self, nx=1, ny=1, nlam=1):
        self.nx=nx
        self.ny=ny
        self.nlam=nlam

        self.i=np.zeros((nx,ny,nlam))
        self.q=np.zeros((nx,ny,nlam))
        self.u=np.zeros((nx,ny,nlam))
        self.v=np.zeros((nx,ny,nlam))

    def check_types(self):
        import struct

    # Check size of default types. Need 32-bit integers, 64-bit integers and floats
    # 32-bit integers
        if struct.calcsize('<i') == 4:
            int4f='i'
        elif struct.calcsize('<l') == 4:
            int4f='l'
        elif struct.calcsize('<q') == 4:
            int4f='q'
        else:
            print ('This architecture has a non-standard integer size')
            print ('which is not supported in this version. Please, contact the')
            print ('author to get support for this platform.')
            sys.exit(1)
    # 64-bit integers
        if struct.calcsize('<i') == 8:
            intf='i'
        elif struct.calcsize('<l') == 8:
            intf='l'
        elif struct.calcsize('<q') == 8:
            intf='q'
        else:
            print ('This architecture has a non-standard integer size')
            print ('which is not supported in this version. Please, contact the')
            print ('author to get support for this platform.')
            sys.exit(1)
    # 64-bit floats
        if struct.calcsize('<f') == 8:
            flf='f'
        elif struct.calcsize('<d') == 8:
            flf='d'
        else:
            print ('This architecture has a non-standard float size')
            print ('which is not supported in this version. Please, contact the')
            print ('author to get support for this platform.')
            sys.exit(1)
        return [int4f,intf,flf]

    
    def read(self,filename):
        import sys, os, struct
        
        [int4f,intf,flf]=self.check_types()
        try:
            f=open(filename,'rb')
        except:
            print ('Could not find model file:',filename)
            sys.exit(1)
        header=f.read(16+8+8)
        [string,nx,ny,nlam]=struct.unpack('<16s'+int4f+int4f+intf,header)
        f.close()
        if string != b'nicole2.3bp     ':
            print('Incorrect version file. Verision string:',string)
            sys.exit(1)
        filesize=os.path.getsize(filename)
        if filesize != (4*nlam)*(nx*ny+1)*8:
            print ('Incorrect size of model file:',filename)
            print ('The file is probably corrupted. Proceeding anyway...')
        self.__init__(nx,ny,nlam)

        sizerec=nlam*4
        f=open(filename,'rb')
        data=struct.unpack('<'+str(sizerec)+flf,f.read(sizerec*8))
        ind=np.arange(0,4*nlam,4)
        for ix in np.arange(nx):
            for iy in range(ny):
                data=struct.unpack('<'+str(sizerec)+flf,f.read(sizerec*8))
                data=np.array(data)
                self.i[ix,iy,:]=data[ind]
                self.q[ix,iy,:]=data[ind+1]
                self.u[ix,iy,:]=data[ind+2]
                self.v[ix,iy,:]=data[ind+3]
    
    def write(self,filename):
        import sys, os, struct
        
        [int4f,intf,flf]=self.check_types()
        try:
            f=open(filename,'wb')
        except:
            print ('Error! Unable to open file for writing')
            sys.exit(1)

        sizerec=self.nlam*4
        f.write(struct.pack('<16s'+int4f+int4f+intf,b'nicole2.3bp     ',self.nx,self.ny,self.nlam))
        for i in range(int(sizerec-16/8-1-1)): f.write(struct.pack('<'+flf,0.)) # Fill rest of record
        ind=np.arange(0,4*self.nlam,4)
        data=np.zeros(sizerec)
        for ix in range(self.nx):
            for iy in range(self.ny):
                data[ind]=self.i[ix,iy,:]
                data[ind+1]=self.q[ix,iy,:]
                data[ind+2]=self.u[ix,iy,:]
                data[ind+3]=self.v[ix,iy,:]

                f.write(struct.pack('<'+str(sizerec)+flf,*data))

        
    def copy(self,indx=None,indy=None):
        if indx == None:
            indx=range(self.nx)
        if indy == None:
            indy=range(self.ny)
        if type(indx) == int:
            indx=[indx]
        if type(indy) == int:
            indy=[indy]
            
        nx2=len(indx)
        ny2=len(indy)
        stk2=stokes(nx2,ny2,self.nlam)
        for ix2 in range(nx2):
            for iy2 in range(ny2):
                ix=indx[ix2]
                iy=indy[iy2]
                stk2.i[ix2,iy2,:]=self.i[ix,iy,:]
                stk2.q[ix2,iy2,:]=self.q[ix,iy,:]
                stk2.u[ix2,iy2,:]=self.u[ix,iy,:]
                stk2.v[ix2,iy2,:]=self.v[ix,iy,:]
        return stk2
    
