#!/usr/bin/env python3
import numpy as np
import scipy, astropy, astropy.constants as C, astropy.units as U,sys
from matplotlib import pyplot as plt
import rotation

import struct

# From CG in the chat of hell

[vel,line_profile]=np.load('line_profile.npy') 
lp1=1.-line_profile
lp1=lp1/max(lp1)

eps=0.3
#vrot=80.
vrot=70.
theta=[.1,0.,vrot,eps,6,1e-2,1.,1.e-3]

#lp2=rotation.rot_profile(theta,vel)
#plt.plot(vel,lp1)
#plt.plot(vel,lp2)
#plt.savefig('tmp.jpg')
#sys.exit(0)


filename='Instrumental_profile.dat'
# Data from NICOLE.input on wavelength grid
nregions=3
nlam=1280
dlambda=0.015625*U.A
l0=8532.0996*U.A
l1=l0+dlambda*nlam

f=open(filename,'wb')

#lambd=8542.09*U.A + vel/C.c* 8542.09*U.A

ll=np.linspace(start=l0,stop=l1,num=nlam)
vscale=(ll.value[:]-8542.09)/8542.09*C.c.to('km/s').value
y=rotation.rot_profile(theta,vscale)
i0=np.argmax(y)
y2=np.concatenate((y[i0:i0+200],y[i0-200:i0]))

print('length of instrumental profile=',len(y2))
if len(y2)/2 == int(len(y2)/2):
    y2=np.concatenate((y[i0:i0+201],y[i0-200:i0]))
    print('length2 of instrumental profile=',len(y2))

#plt.plot(y2)
#plt.show()

mm=len(y2)
data=np.array([0.]*nlam*nregions)
data[0:nregions]=mm
s=struct.pack('d'*len(data),*data)
f.write(s)

index=0
for iregion in range(nregions):
    data[index:index+len(y2)]=y2/np.sum(y2)
    index=index+len(y2)
print('ind=',index)
s=struct.pack('d'*len(data),*data)
f.write(s)

f.close()

#plt.plot(y2)
#plt.savefig('tmp.jpg')

