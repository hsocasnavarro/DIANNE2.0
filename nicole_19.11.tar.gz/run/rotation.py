#!/usr/bin/env python3
from astropy.modeling.functional_models import Voigt1D
import numpy as np

def rot_profile(theta,v_obs,voigt=True):
    #
    if voigt:
        i_core,v0,v_r,eps,g_fwhm,l_fwhm,cont_level,err_bias=theta
    else:
        i_core,v0,v_r,eps,cont_level=theta
    #
    # Centered vel
    #
    vz=v_obs-v0
    #
    g_rot=((1-eps) * np.sqrt(1-(vz/v_r)**2) + 0.5*np.pi*eps*(1-(vz/v_r)**2)) / \
        (np.pi*v_r * (1-eps/3.0))
    #
    g_rot[np.abs(vz)>v_r]=0
    g_rot=g_rot.clip(min=0)
    if voigt:
        v_p=Voigt1D(x_0=0.0, amplitude_L=1.0, fwhm_L=l_fwhm, fwhm_G=g_fwhm)
        g_voigt=v_p(vz)
        profile=np.convolve(g_rot,g_voigt,mode='same')
    else:
        profile=g_v
    #
    return profile/np.max(profile)

