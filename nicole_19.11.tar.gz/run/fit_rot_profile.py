import numpy as np
from scipy.interpolate import interp1d
import astropy.io.ascii as at
import pickle as pk
from astropy.modeling.functional_models import Voigt1D
import pylab as pl
from scipy.optimize import minimize
from gausslib import dogauss,fitgauss
import emcee as mc
import corner
import astropy.io.fits as pf
#
def MAD(x):
    return np.median(np.abs(x-np.median(x)))
#
#
def rot_profile(theta,v_obs,voigt=True):
    #
    if voigt:
        i_core,v0,v_r,eps,g_fwhm,l_fwhm,cont_level,err_bias=theta
    else:
        i_core,v0,v_r,eps,cont_level=theta
    #
    # Centered vel
    #
    vz=v_obs-v0
    #
    g_rot=((1-eps) * np.sqrt(1-(vz/v_r)**2) + 0.5*np.pi*eps*(1-(vz/v_r)**2)) / \
        (np.pi*v_r * (1-eps/3.0))
    #
    g_rot[np.abs(vz)>v_r]=0
    g_rot=g_rot.clip(min=0)
    if voigt:
        v_p=Voigt1D(x_0=0.0, amplitude_L=1.0, fwhm_L=l_fwhm, fwhm_G=g_fwhm)
        g_voigt=v_p(vz)
        profile=np.convolve(g_rot,g_voigt,mode='same')
    else:
        profile=g_v
    #
    return cont_level-i_core*profile/np.max(profile)
#
#
################################################################################
#
################################################################################
#
#
def print_theta(theta):
    s = ''
    for i in theta:
        s += '{0:.3f} '.format(i)
    return s
#
#
#
def logprior(theta):
    #
    # i_core,v0,v_r,eps,g_fwhm,l_fwhm=theta
    #
    lp = 0.0
    #
    # lp += -0.5*(theta[0]/0.5)**2-0.5*np.log(2*np.pi*0.5**2)
    #
    lp += -0.5*((theta[0]-0.5)/0.2)**2-0.5*np.log(2*np.pi*0.2**2)
    #
    # lp += -0.5*(theta[1]/10)**2-0.5*np.log(2*np.pi*10**2)
    if theta[1] < -10:
        return -np.inf
    if theta[1] > 10:
        return -np.inf
    lp += -np.log(10)
    #
    if theta[2] <30:
        return -np.inf
    if theta[2] > 1e3:
        return -np.inf
    #
    lp += -np.log(theta[2]) - np.log(np.log(1e3 / 1))
    #
    if theta[3] < -10:
        return -np.inf
    if theta[3] > 10:
        return -np.inf
    lp += -np.log(200)
    #
    if theta[4] <1:
        return -np.inf
    if theta[4] > 1e3:
        return -np.inf
    #
    lp += -np.log(theta[4]) - np.log(np.log(1e3 / 1))
    #
    if theta[5] <1e-4:
        return -np.inf
    if theta[5] > 1e3:
        return -np.inf
    #
    lp += -np.log(theta[5]) - np.log(np.log(1e3 / 1e-4))
    #
    if theta[6] <0:
        return -np.inf
    if theta[6] > 1:
        return -np.inf
    #
    if theta[7] <1e-9:
        return -np.inf
    if theta[7] > 10.:
        return -np.inf
    #
    lp += -np.log(theta[7]) - np.log(np.log(1 / 1e-9))
    #
    #
    return lp
#
#
#
def loglike(theta, v_obs, f_obs, f_error, \
            do_print=False, check_pars=False):
    #
    #
    if check_pars:
        lp = logprior(theta)
        #
        if not np.isfinite(lp):
            return -np.inf
    #
    # l_t=np.sqrt(1 / (2 * np.pi * error_f ** 2)) * \
    #     (np.exp(-0.5 * ((f_obj -theta[line_interval + n_steps + n_lines] + \
    #                      theta[line_interval + n_steps] * theta[v_interval]) / error_f) ** 2))
    #
    l_t = np.sqrt(1 / (2 * np.pi * f_error*theta[-1] ** 2)) * \
          (np.exp(-0.5 * ((f_obs - rot_profile(theta,v_obs,voigt=True)) / \
          (f_error*theta[-1])) ** 2))
    #
    loglike = np.log(l_t.clip(1e-200)).sum()
    #
    if do_print:
        print(print_theta(theta), loglike)
    #
    return loglike
#
#
#
def logprob(theta, v_obs, f_obs, f_error):
    #
    lp = logprior(theta)
    #
    if not np.isfinite(lp):
        return -np.inf
    #
    #
    llh = loglike(theta, v_obs, f_obs, f_error)
    if not np.isfinite(llh):
        return -np.inf
    #
    if np.random.uniform(0, 1) < 0.03:
        print(print_theta(theta), '{0:.4f}  {1:.4f}'.format(llh, lp))
    #
    return lp + llh
#
#
################################################################################
#
################################################################################
#
# Load MCMC profile
#
tabby_not=False
fit_avg=True
# temp=pf.open('lsd_harps_old_kurucz.fits')
# tail='_fies_old'
# temp=pf.open('lsd_tabby_may_kurucz.fits')
temp=pf.open('lsd_tabby_july_kurucz.fits')
# tail='_mer_all'
# temp=pf.open('lsd_harps_kurucz.fits')
lsd_raw = temp[0].data
tail='_mer_all'
# temp=pf.open('lsd_harps_kurucz.fits')
temp.close()
lsd_vel = np.arange(150)*400./149.-200.
# lsd=lsd_raw.sum(0)/43. # el primero tiene cielo
# lsd_err=0.001*lsd
# lsd=lsd_raw.sum(0)/3. 
# lsd_err=lsd_raw.std(0)/np.sqrt(3.)
#
#
def min_func(theta,*args):
    return -1.0*loglike(theta,*args)
#
#
#
for i in range(lsd_raw.shape[0]):
    lsd=lsd_raw[i,]
    if fit_avg:
        lsd=np.mean(lsd_raw,0)
    lsd_err=0.001*lsd
    # if i==0:
    #     i_t=np.where((lsd_vel>0)&(lsd_vel<30))[0]
    #     lsd_err[i_t]*=5.
    if tabby_not:
        i_t=np.where((lsd_vel>-15)&(lsd_vel<15))[0]
        lsd_err[i_t]*=10.
    #
    i_t=np.where((lsd_vel>-120)&(lsd_vel<120))[0]
    cof_0=[0.07,2,80,0.5,11,1,lsd[0:10].mean(),1.0]
    res = minimize(min_func, cof_0, method='Powell', \
                args=(lsd_vel[i_t], lsd[i_t], lsd_err[i_t]*10., True, True))
    # acabo de hacer los errores grandes, corregir
    res['x'][-1]*=10.
    #
    ndim=len(cof_0)
    nwalkers=2*ndim
    ini_pos = [res['x'] + 0.05 * np.random.uniform(0, 1, ndim) \
            for k in range(nwalkers)]
    sampler = mc.EnsembleSampler(nwalkers, ndim, logprob, \
                                args=(lsd_vel[i_t], lsd[i_t], lsd_err[i_t]))
    sampler.run_mcmc(ini_pos, 10000)
    #
    samples = sampler.chain
    samples = samples[:, 5000:, :].reshape((-1, ndim))
    cof = np.median(samples, 0)
    #
    pl.clf()
    pl.plot(lsd_vel, lsd,'b-',lw=2)
    pl.plot(lsd_vel, lsd+cof[-1]*lsd_err,'c--',lw=1)
    pl.plot(lsd_vel, lsd-cof[-1]*lsd_err,'c--',lw=1)
    pl.plot(lsd_vel,rot_profile(cof,lsd_vel,voigt=True),'r-',lw=2)
    pl.xlabel('V (km/s)')
    pl.ylabel('I')
    pl.savefig('fit_rot'+tail+'{0:03d}.png'.format(i))
    #
    import corner
    pl.clf()
    fig = corner.corner(samples, labels=["$I_0$", "$V_0$", "$V_r$", "$\epsilon$","$FWHM_G$",\
        "$FWHM_L$","C",'err'],
                        truths=cof)
    fig.savefig('triangle_rot'+tail+'{0:03d}.png'.format(i))
    #
    temp=open('rot_prof_'+tail+'{0:03d}.pk'.format(i),'wb')
    pk.dump([cof,samples],temp)
    temp.close()
    #
    cof = np.median(samples, 0)
    dcof=np.percentile(samples,(2.5,97.5),0)
    #
    file_out = open('fit_all'+tail+'.dat', 'a')          
    if i==0:
        file_out.write('#\n')
        file_out.write('# N\tI0\tV0\tVr\teps\tFWHM_G\tFWHM_L\tC\terr\n')
        file_out.write('#\n')
    t='spec#{0:03d}\t'.format(i)
    for j in range(len(cof)):
        t+='{0:.4f}\t'.format(cof[j])
        t+='{0:.4f}\t'.format(dcof[0,j]-cof[j])
        t+='{0:.4f}\t'.format(dcof[1,j]-cof[j])
    t=t[0:-1]+'\n'
    file_out.write(t)
    file_out.close()
    #
    if fit_avg:
        break
